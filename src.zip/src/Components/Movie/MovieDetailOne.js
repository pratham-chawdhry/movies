import React from 'react'

export default function MovieDetailOne() {
  return (
    <div>
      
    </div>
  )
}
